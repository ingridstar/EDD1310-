package estructura.d.datos;

public class ArregloS1 {
	private int tamanio;
	private int largo;
	private int componente;
	public void Array(int tamanio, int longitud, int elemento) {
		this.tamanio = tamanio;
		this.largo = largo;
		this.componente = componente;
	}
	public int getLargo() {
		return tamanio;
	}
	public int getComponente(int indice) {
		return componente;
	}
	public void setElemento(int indice, String valor) {
	}
	public void limpiar (String valor){     
    }
	@Override
	public String toString() {
		String componente = null;
		return "Arreglo {" + "tama\u00f1o: " + tamanio + ", largo:" + largo + ", componente:" + componente + '}';
	}
}

